private void displayLoggers() {
		LogManager lm = LogManager.getLogManager();
		TreeSet<String> names = new TreeSet<String>();
		for(Enumeration<String> e = lm.getLoggerNames(); e.hasMoreElements(); ) {
			Logger logger = lm.getLogger(e.nextElement());
			StringBuilder output = new StringBuilder();
			if(logger.getName().length() == 0) {
				output.append("<<default logger>>");
			} else {
				output.append(logger.getName());
			}

			if(logger.getHandlers().length == 0) {
				output.append(" : disabled");
			} else {
				output.append(" : enabled");
				output.append(" (");
				Level level = logger.getLevel();
				if (level != null) {
					String name = level.getName();
					output.append(name);
				}
				output.append(") ");
			}
			names.add(output.toString());
		}
		out.println("Currently installed loggers :-");
		for(String name : names) {
			out.print("\t");
			out.println(name);
		}
	}