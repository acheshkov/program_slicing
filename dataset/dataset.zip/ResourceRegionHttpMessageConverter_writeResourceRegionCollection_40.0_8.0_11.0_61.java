private void writeResourceRegionCollection(Collection<ResourceRegion> resourceRegions,
			HttpOutputMessage outputMessage) throws IOException {

		Assert.notNull(resourceRegions, "Collection of ResourceRegion should not be null");
		HttpHeaders responseHeaders = outputMessage.getHeaders();

		MediaType contentType = responseHeaders.getContentType();
		String boundaryString = MimeTypeUtils.generateMultipartBoundaryString();
		responseHeaders.set(HttpHeaders.CONTENT_TYPE, "multipart/byteranges; boundary=" + boundaryString);
		OutputStream out = outputMessage.getBody();

		Resource resource = null;
		InputStream in = null;
		long inputStreamPosition = 0;

		try {
			for (ResourceRegion region : resourceRegions) {
				long start = region.getPosition() - inputStreamPosition;
				if (start < 0 || resource != region.getResource()) {
					if (in != null) {
						in.close();
					}
					resource = region.getResource();
					in = resource.getInputStream();
					inputStreamPosition = 0;
					start = region.getPosition();
				}
				long end = start + region.getCount() - 1;
				// Writing MIME header.
				println(out);
				print(out, "--" + boundaryString);
				println(out);
				if (contentType != null) {
					print(out, "Content-Type: " + contentType.toString());
					println(out);
				}
				Long resourceLength = region.getResource().contentLength();
				end = Math.min(end, resourceLength - inputStreamPosition - 1);
				print(out, "Content-Range: bytes " +
						region.getPosition() + '-' + (region.getPosition() + region.getCount() - 1) +
						'/' + resourceLength);
				println(out);
				println(out);
				// Printing content
				StreamUtils.copyRange(in, out, start, end);
				inputStreamPosition += (end + 1);
			}
		}
		finally {
			try {
				if (in != null) {
					in.close();
				}
			}
			catch (IOException ex) {
				// ignore
			}
		}

		println(out);
		print(out, "--" + boundaryString + "--");
	}