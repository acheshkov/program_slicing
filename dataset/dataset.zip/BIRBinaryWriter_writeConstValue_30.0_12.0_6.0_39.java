private void writeConstValue(ByteBuf buf, ConstValue constValue) {
        writeType(buf, constValue.type);
        switch (constValue.type.tag) {
            case TypeTags.INT:
                buf.writeInt(addIntCPEntry((Long) constValue.value));
                break;
            case TypeTags.BYTE:
                int byteValue = ((Number) constValue.value).intValue();
                buf.writeInt(addByteCPEntry(byteValue));
                break;
            case TypeTags.FLOAT:
                // TODO:Remove the instanceof check by converting the float literal instance in Semantic analysis phase
                double doubleVal = constValue.value instanceof String ? Double.parseDouble((String) constValue.value)
                        : (Double) constValue.value;
                buf.writeInt(addFloatCPEntry(doubleVal));
                break;
            case TypeTags.STRING:
            case TypeTags.DECIMAL:
                buf.writeInt(addStringCPEntry((String) constValue.value));
                break;
            case TypeTags.BOOLEAN:
                buf.writeByte((Boolean) constValue.value ? 1 : 0);
                break;
            case TypeTags.NIL:
                break;
            case TypeTags.MAP:
                Map<String, ConstValue> mapConstVal = (Map<String, ConstValue>) constValue.value;
                buf.writeInt(mapConstVal.size());
                mapConstVal.forEach((key, value) -> {
                    buf.writeInt(addStringCPEntry(key));
                    writeConstValue(buf, value);
                });
                break;
            default:
                // TODO support for other types
                throw new UnsupportedOperationException(
                        "finite type value is not supported for type: " + constValue.type);

        }
    }