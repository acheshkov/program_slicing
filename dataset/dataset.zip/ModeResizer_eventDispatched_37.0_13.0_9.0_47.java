@Override
    public void eventDispatched( AWTEvent e ) {
        if( !(e instanceof KeyEvent) )
            return;
        KeyEvent ke = ( KeyEvent ) e;
        ke.consume();
        
        if( e.getID() == KeyEvent.KEY_PRESSED ) {
            int nStep = 0;

            switch( ke.getModifiers() ) {
                case InputEvent.SHIFT_MASK:
                    nStep = STEP_SMALL;
                    break;

                case 0:
                    nStep = STEP_NORMAL;
                    break;

                case InputEvent.CTRL_MASK:
                    nStep = STEP_LARGE;
                    break;
            }

            if( nStep != 0 ) {
                switch( ke.getKeyCode() ) {
                    case KeyEvent.VK_LEFT:
                        moveBy( -nStep, 0 );
                        break;
                    case KeyEvent.VK_RIGHT:
                        moveBy( nStep, 0 );
                        break;
                    case KeyEvent.VK_UP:
                        moveBy( 0, -nStep );
                        break;
                    case KeyEvent.VK_DOWN:
                        moveBy( 0, nStep );
                        break;
                    case KeyEvent.VK_ENTER:
                        stop( true );
                        break;
                    case KeyEvent.VK_ESCAPE:
                        stop( true );
                        break;
                }
            }
        }
    }