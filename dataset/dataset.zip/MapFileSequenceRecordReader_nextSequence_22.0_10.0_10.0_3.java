@Override
    public SequenceRecord nextSequence() {
        return nextSequence(true);
    }