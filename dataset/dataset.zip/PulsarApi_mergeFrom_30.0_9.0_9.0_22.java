public Builder mergeFrom(org.apache.pulsar.common.api.proto.PulsarApi.Schema other) {
        if (other == org.apache.pulsar.common.api.proto.PulsarApi.Schema.getDefaultInstance()) return this;
        if (other.hasName()) {
          setName(other.getName());
        }
        if (other.hasSchemaData()) {
          setSchemaData(other.getSchemaData());
        }
        if (other.hasType()) {
          setType(other.getType());
        }
        if (!other.properties_.isEmpty()) {
          if (properties_.isEmpty()) {
            properties_ = other.properties_;
            bitField0_ = (bitField0_ & ~0x00000008);
          } else {
            ensurePropertiesIsMutable();
            properties_.addAll(other.properties_);
          }
          
        }
        return this;
      }