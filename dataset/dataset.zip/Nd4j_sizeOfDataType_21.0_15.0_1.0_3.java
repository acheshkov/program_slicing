@Deprecated
    public static int sizeOfDataType() {
        return sizeOfDataType(Nd4j.dataType());
    }