public static IFile createGhidraScript(IFolder scriptFolder, String scriptName,
			String scriptAuthor, String scriptCategory, String[] scriptDescription,
			IProgressMonitor monitor) throws CoreException, IOException {

		// Create the scripts folder directory, if necessary
		if (!scriptFolder.exists()) {
			GhidraProjectUtils.createFolder(scriptFolder, monitor);
		}

		IFile scriptFile = scriptFolder.getFile(scriptName);
		
		// Does the script exist already?  If so, it's a problem.
		if (scriptFile.exists()) {
			throw new IOException("File already exists: " + scriptFile);
		}

		// Create the script file, and fill in a useful entry point
		try (PrintWriter writer =
			new PrintWriter(new FileWriter(scriptFile.getLocation().toFile()))) {
			if (scriptName.endsWith(".java")) {
				Arrays.stream(scriptDescription).forEach(line -> writer.println("//" + line));
				writer.println("//@author " + scriptAuthor);
				writer.println("//@category " + scriptCategory);
				writer.println("//@keybinding");
				writer.println("//@menupath");
				writer.println("//@toolbar");
				writer.println();
				writer.println("import ghidra.app.script.GhidraScript;");
				writer.println();
				writer.println("public class " + scriptName.substring(0, scriptName.length() - 5) +
						" extends GhidraScript {");
				writer.println();
				writer.println("\t@Override");
				writer.println("\tprotected void run() throws Exception {");
				writer.println("\t\t//TODO: Add script code here");
				writer.println("\t}");
				writer.println("}");
			}
			else if (scriptName.endsWith(".py")) {
				Arrays.stream(scriptDescription).forEach(line -> writer.println("#" + line));
				writer.println("#@author " + scriptAuthor);
				writer.println("#@category " + scriptCategory);
				writer.println("#@keybinding");
				writer.println("#@menupath");
				writer.println("#@toolbar");
				writer.println();
				writer.println("#TODO: Add script code here");
			}
		}
		catch (IOException e) {
			throw new IOException("Failed to create: " + scriptFile);
		}

		// Refresh project to it sees the new script
		scriptFile.getProject().refreshLocal(IResource.DEPTH_INFINITE, monitor);

		return scriptFile;
	}